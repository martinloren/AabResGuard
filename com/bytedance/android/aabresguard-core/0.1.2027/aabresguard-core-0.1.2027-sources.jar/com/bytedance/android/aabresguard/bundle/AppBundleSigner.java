package com.bytedance.android.aabresguard.bundle;

import com.bytedance.android.aabresguard.android.JarSigner;
import com.bytedance.android.aabresguard.utils.TimeClock;

import java.io.IOException;
import java.nio.file.Path;

/**
 * Created by YangJing on 2019/10/11 .
 * Email: yangjing.yeoh@bytedance.com
 */
public class AppBundleSigner {

    private Path bundleFile;
    private JarSigner.Signature bundleSignature;

    public AppBundleSigner(Path bundleFile, JarSigner.Signature signature) {
        this.bundleFile = bundleFile;
        this.bundleSignature = signature;
    }

    public AppBundleSigner(Path bundleFile) {
        this.bundleFile = bundleFile;
    }

    public void setBundleSignature(JarSigner.Signature bundleSignature) {
        this.bundleSignature = bundleSignature;
    }

    public void execute() throws IOException, InterruptedException {
        if (bundleSignature == null) {
            System.err.println("WARNING: no signing config found, the bundle is left UNSIGNED!");
            return;
        }
        TimeClock timeClock = new TimeClock();
        JarSigner.Signature signature = new JarSigner.Signature(
                bundleSignature.storeFile,
                bundleSignature.storePassword,
                bundleSignature.keyAlias,
                bundleSignature.keyPassword
        );
        new JarSigner().sign(bundleFile.toFile(), signature);
        System.out.println(String.format("[sign] sign done, cost: %s", timeClock.getCost()));
    }
}
